import React from 'react';

// Esta é uma página de placeholder. Em uma aplicação real, você usaria um router
// para pegar o 'slug' da URL e carregar o conteúdo do post correspondente.
const BlogPostPage = () => {
  // Dados mocados para um post de exemplo
  const post = {
    title: '10 Prompts \'Mágicos\' para Desbloquear a Criatividade da IA (Texto)',
    author: 'Equipe IA Generativa',
    date: '16 de Maio de 2025',
    imageUrl: 'https://via.placeholder.com/800x400/FFA07A/000000?text=IA+Texto+Detalhe',
    content: `
      <p>Cansado de encarar o cursor piscando ou de receber respostas genéricas da Inteligência Artificial? O segredo para desbloquear o verdadeiro potencial criativo da IA de texto está na arte de criar o prompt certo! Um bom prompt é como um mapa do tesouro: guia a IA diretamente para o resultado incrível que você busca. Para facilitar sua vida, separamos 10 estruturas de prompt "mágicas" e testadas que vão turbinar sua produção de conteúdo textual. Prepare o print (ou o bloco de notas) e comece a criar!</p>
      
      <h2>1. O Gerador de Ideias Infinitas:</h2>
      <p><strong>Prompt Mágico:</strong> "Aja como um especialista em [Seu Nicho]. Gere 10 ideias de posts de blog/vídeos/newsletters sobre [Tema Específico] que sejam [Adjetivo 1, ex: inovadoras], [Adjetivo 2, ex: práticas] e [Adjetivo 3, ex: relevantes] para [Seu Público-Alvo]. Para cada ideia, forneça um título chamativo e uma breve descrição (1-2 frases)."</p>
      <p><strong>Por que funciona:</strong> Define a persona da IA, o público, o tema e o tipo de resultado esperado, garantindo ideias mais alinhadas.</p>
      
      <h2>2. O Criador de Outlines Detalhados:</h2>
      <p><strong>Prompt Mágico:</strong> "Crie um outline detalhado para um artigo/roteiro de vídeo intitulado '[Título do Conteúdo]'. O conteúdo deve ter aproximadamente [Número] palavras/minutos e ser direcionado para [Público-Alvo]. O outline deve incluir: Introdução com gancho, [Número] seções principais com subtítulos claros, pontos-chave para cada seção, e uma conclusão com chamada para ação."</p>
      <p><strong>Por que funciona:</strong> Estrutura o pensamento da IA, garantindo que todos os pontos importantes sejam cobertos de forma lógica.</p>
      
      {/* Adicionar os outros 8 prompts do Texto 2.1 aqui... */}

      <p>Lembre-se, esses prompts são pontos de partida! A verdadeira mágica acontece quando você os adapta ao seu nicho, ao seu público e à sua voz única. Experimente, itere e veja a IA se tornar sua maior aliada na criação de conteúdo textual.</p>
    `
  };

  // Simula a obtenção do slug da URL
  // Em um app real, você usaria useParams() do React Router DOM
  const slug = window.location.pathname.split('/').pop();
  let currentPost = post; // Placeholder, deveria buscar o post pelo slug

  // Se você tivesse múltiplos posts, você faria algo como:
  // const postsData = { '10-prompts-magicos-ia-texto': post, ...outrosPosts };
  // currentPost = postsData[slug] || { title: 'Post Não Encontrado', content: '<p>O post que você procura não foi encontrado.</p>' };

  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <article>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem', color: '#007bff' }}>{currentPost.title}</h1>
        <p style={{ color: '#555', marginBottom: '0.5rem' }}>Por: {currentPost.author} | Data: {currentPost.date}</p>
        {currentPost.imageUrl && 
          <img src={currentPost.imageUrl} alt={currentPost.title} style={{ width: '100%', height: 'auto', borderRadius: '8px', marginBottom: '2rem' }} />
        }
        <div dangerouslySetInnerHTML={{ __html: currentPost.content }} style={{ lineHeight: '1.7', fontSize: '1.1rem' }} />
      </article>
      
      {/* Seção de Comentários (Placeholder) */}
      <section style={{ marginTop: '3rem', paddingTop: '2rem', borderTop: '1px solid #eee' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem' }}>Comentários</h2>
        <p>Sistema de comentários será implementado aqui.</p>
        {/* Formulário de comentário e lista de comentários */}
      </section>

      {/* Posts Relacionados (Placeholder) */}
      <section style={{ marginTop: '3rem', paddingTop: '2rem', borderTop: '1px solid #eee' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem' }}>Posts Relacionados</h2>
        <p>Links para outros posts do blog aqui.</p>
      </section>
    </div>
  );
};

export default BlogPostPage;

