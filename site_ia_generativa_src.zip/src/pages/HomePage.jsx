import React from 'react';

const HomePage = () => {
  return (
    <div>
      {/* Seção Herói */}
      <section style={{ textAlign: 'center', padding: '4rem 2rem', backgroundColor: '#e9ecef' }}>
        <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>Desbloqueie Sua Criatividade com Inteligência Artificial Generativa!</h1>
        <p style={{ fontSize: '1.25rem', marginBottom: '2rem' }}>Aprenda a criar conteúdo incrível, otimizar seu tempo e se destacar no mercado digital com o poder da IA.</p>
        <a href="/produto" style={{ textDecoration: 'none', backgroundColor: '#007bff', color: 'white', padding: '1rem 2rem', fontSize: '1.25rem', borderRadius: '5px' }}>Conheça o Curso Completo</a>
      </section>

      {/* Seção: Para Quem é Este Curso? */}
      <section style={{ padding: '4rem 2rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '3rem' }}>Este Curso é Para Você Se...</h2>
        <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
          <div style={{ maxWidth: '300px', margin: '1rem' }}>
            {/* Ícone aqui */}
            <h3 style={{ fontSize: '1.5rem' }}>Criadores de Conteúdo</h3>
            <p>Querem inovar e produzir mais, com mais qualidade.</p>
          </div>
          <div style={{ maxWidth: '300px', margin: '1rem' }}>
            {/* Ícone aqui */}
            <h3 style={{ fontSize: '1.5rem' }}>Profissionais de Marketing</h3>
            <p>Buscam otimizar campanhas e criar materiais atraentes.</p>
          </div>
          <div style={{ maxWidth: '300px', margin: '1rem' }}>
            {/* Ícone aqui */}
            <h3 style={{ fontSize: '1.5rem' }}>Empreendedores</h3>
            <p>Desejam alavancar seus negócios com conteúdo de impacto.</p>
          </div>
        </div>
      </section>

      {/* Seção: O Que Você Vai Aprender? (Destaque dos Módulos) */}
      <section style={{ padding: '4rem 2rem', backgroundColor: '#f8f9fa', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '3rem' }}>Transforme Sua Criação de Conteúdo: Veja o Que Te Espera</h2>
        {/* Cards dos Módulos aqui - Exemplo */}
        <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
          <div style={{ border: '1px solid #ddd', borderRadius: '5px', padding: '2rem', margin: '1rem', maxWidth: '300px' }}>
            <h3 style={{ fontSize: '1.5rem' }}>Módulo 1: Fundamentos</h3>
            <p>Entenda a base da IA Generativa e seu potencial.</p>
            <a href="/produto/modulo-1">Saiba Mais</a>
          </div>
          <div style={{ border: '1px solid #ddd', borderRadius: '5px', padding: '2rem', margin: '1rem', maxWidth: '300px' }}>
            <h3 style={{ fontSize: '1.5rem' }}>Módulo 2: Ferramentas na Prática</h3>
            <p>Domine as principais ferramentas de texto e imagem.</p>
            <a href="/produto/modulo-2">Saiba Mais</a>
          </div>
          {/* Adicionar mais módulos conforme necessário */}
        </div>
        <a href="/produto" style={{ display: 'inline-block', marginTop: '3rem', textDecoration: 'none', backgroundColor: '#28a745', color: 'white', padding: '1rem 2rem', fontSize: '1.25rem', borderRadius: '5px' }}>Ver Conteúdo Programático Completo</a>
      </section>

      {/* Seção: Blog (Últimos Artigos) */}
      <section style={{ padding: '4rem 2rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '3rem' }}>Fique por Dentro: Nosso Blog Sobre IA Generativa</h2>
        {/* Cards dos Artigos aqui - Exemplo */}
        <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
          <article style={{ border: '1px solid #ddd', borderRadius: '5px', padding: '1rem', margin: '1rem', maxWidth: '300px' }}>
            <h3 style={{ fontSize: '1.5rem' }}>Título do Artigo 1</h3>
            <p>Resumo do artigo...</p>
            <a href="/blog/artigo-1">Leia Mais</a>
          </article>
          <article style={{ border: '1px solid #ddd', borderRadius: '5px', padding: '1rem', margin: '1rem', maxWidth: '300px' }}>
            <h3 style={{ fontSize: '1.5rem' }}>Título do Artigo 2</h3>
            <p>Resumo do artigo...</p>
            <a href="/blog/artigo-2">Leia Mais</a>
          </article>
        </div>
        <a href="/blog" style={{ display: 'inline-block', marginTop: '3rem', textDecoration: 'none', backgroundColor: '#17a2b8', color: 'white', padding: '1rem 2rem', fontSize: '1.25rem', borderRadius: '5px' }}>Visite Nosso Blog</a>
      </section>

      {/* Seção: Captura de Leads */}
      <section style={{ padding: '4rem 2rem', backgroundColor: '#6c757d', color: 'white', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>Receba Dicas Exclusivas e Novidades!</h2>
        <p style={{ marginBottom: '2rem' }}>Inscreva-se para receber nosso material gratuito e ficar atualizado sobre IA Generativa.</p>
        <form style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <input type="email" placeholder="Seu melhor e-mail" style={{ padding: '0.75rem', marginRight: '0.5rem', borderRadius: '5px', border: 'none', minWidth: '250px' }} />
          <button type="submit" style={{ backgroundColor: '#ffc107', color: '#333', padding: '0.75rem 1.5rem', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>Inscrever-se</button>
        </form>
      </section>
    </div>
  );
};

export default HomePage;
