import React from 'react';

const TermosUsoPage = () => {
  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', textAlign: 'center' }}>Termos de Uso</h1>
      <p style={{ fontSize: '1rem', marginBottom: '1rem', color: '#666' }}>
        Última atualização: 16 de Maio de 2025
      </p>
      
      <div style={{ lineHeight: '1.6' }}>
        <p style={{ marginBottom: '1.5rem' }}>
          Bem-vindo ao site do produto "Criação de Conteúdo com Inteligência Artificial Generativa". Ao acessar ou utilizar nosso site e serviços, você concorda com estes Termos de Uso. Por favor, leia-os atentamente.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>1. Aceitação dos Termos</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Ao acessar ou utilizar nosso site, você concorda em ficar vinculado a estes Termos de Uso, todas as leis e regulamentos aplicáveis, e concorda que é responsável pelo cumprimento de quaisquer leis locais aplicáveis. Se você não concordar com algum destes termos, está proibido de usar ou acessar este site.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>2. Uso da Licença</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          É concedida permissão para acessar temporariamente o site e seus materiais para uso pessoal e não comercial. Esta é a concessão de uma licença, não uma transferência de título, e sob esta licença você não pode:
        </p>
        <ul style={{ marginBottom: '1.5rem', paddingLeft: '2rem' }}>
          <li>Modificar ou copiar os materiais;</li>
          <li>Usar os materiais para qualquer finalidade comercial ou para exibição pública;</li>
          <li>Tentar descompilar ou fazer engenharia reversa de qualquer software contido no site;</li>
          <li>Remover quaisquer direitos autorais ou outras notações de propriedade dos materiais; ou</li>
          <li>Transferir os materiais para outra pessoa ou "espelhar" os materiais em qualquer outro servidor.</li>
        </ul>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>3. Conteúdo do Curso</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          O acesso ao conteúdo do curso "Criação de Conteúdo com Inteligência Artificial Generativa" é exclusivo para usuários que adquiriram o produto. O compartilhamento não autorizado do conteúdo é estritamente proibido e pode resultar na revogação do acesso sem reembolso.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>4. Isenção de Responsabilidade</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Os materiais no site são fornecidos "como estão". Não oferecemos garantias, expressas ou implícitas, e por este meio nos isentamos e negamos todas as outras garantias, incluindo, sem limitação, garantias implícitas ou condições de comercialização, adequação a um fim específico ou não violação de propriedade intelectual ou outra violação de direitos.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>5. Limitações</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Em nenhum caso nós ou nossos fornecedores seremos responsáveis por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucro, ou devido a interrupção dos negócios) decorrentes do uso ou da incapacidade de usar os materiais em nosso site, mesmo que nós ou um representante autorizado tenha sido notificado oralmente ou por escrito da possibilidade de tais danos.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>6. Precisão dos Materiais</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Os materiais exibidos no site podem incluir erros técnicos, tipográficos ou fotográficos. Não garantimos que qualquer material em nosso site seja preciso, completo ou atual. Podemos fazer alterações nos materiais contidos em nosso site a qualquer momento, sem aviso prévio.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>7. Links</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Não somos responsáveis pelo conteúdo de qualquer site vinculado ao nosso. A inclusão de qualquer link não implica endosso por nós do site. O uso de qualquer site vinculado é por conta e risco do usuário.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>8. Modificações</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Podemos revisar estes Termos de Uso do site a qualquer momento, sem aviso prévio. Ao usar este site, você concorda em ficar vinculado à versão atual destes Termos de Uso.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>9. Lei Aplicável</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Estes Termos e Condições são regidos e interpretados de acordo com as leis do Brasil, e você se submete irrevogavelmente à jurisdição exclusiva dos tribunais naquele estado ou localidade.
        </p>
      </div>
    </div>
  );
};

export default TermosUsoPage;
