import React from 'react';

const BlogPage = () => {
  // Dados mocados para o blog
  const posts = [
    {
      id: 1,
      title: '10 Prompts \'Mágicos\' para Desbloquear a Criatividade da IA (Texto)',
      slug: '10-prompts-magicos-ia-texto',
      excerpt: 'Cansado de encarar o cursor piscando? O segredo para desbloquear o verdadeiro potencial criativo da IA de texto está na arte de criar o prompt certo!',
      imageUrl: 'https://via.placeholder.com/400x250/FFA07A/000000?text=IA+Texto'
    },
    {
      id: 2,
      title: 'Como Criar Imagens Únicas com IA (Mesmo Sem Saber Desenhar)',
      slug: 'como-criar-imagens-unicas-com-ia',
      excerpt: 'Sonha em Criar Imagens Incríveis? A IA te Ajuda! Ferramentas como Midjourney, DALL-E e Canva AI transformam suas palavras em imagens.',
      imageUrl: 'https://via.placeholder.com/400x250/20B2AA/FFFFFF?text=IA+Imagens'
    },
    {
      id: 3,
      title: 'Checklist: Seu Conteúdo de IA está Pronto para o Público?',
      slug: 'checklist-conteudo-ia-publico',
      excerpt: 'Antes de apertar o botão \'publicar\', existe uma etapa crucial: a validação e o toque humano final. Garanta a qualidade do seu conteúdo gerado por IA.',
      imageUrl: 'https://via.placeholder.com/400x250/778899/FFFFFF?text=Checklist+IA'
    }
  ];

  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2.5rem', marginBottom: '3rem' }}>Blog IA Generativa para Criadores</h1>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
        {posts.map(post => (
          <article key={post.id} style={{ border: '1px solid #ddd', borderRadius: '8px', overflow: 'hidden', boxShadow: '0 2px 5px rgba(0,0,0,0.1)' }}>
            <img src={post.imageUrl} alt={post.title} style={{ width: '100%', height: '200px', objectFit: 'cover' }} />
            <div style={{ padding: '1.5rem' }}>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}><a href={`/blog/${post.slug}`} style={{ textDecoration: 'none', color: '#007bff' }}>{post.title}</a></h2>
              <p style={{ color: '#555', marginBottom: '1.5rem' }}>{post.excerpt}</p>
              <a href={`/blog/${post.slug}`} style={{ textDecoration: 'none', color: '#007bff', fontWeight: 'bold' }}>Leia Mais →</a>
            </div>
          </article>
        ))}
      </div>
      {/* Paginação pode ser adicionada aqui no futuro */}
    </div>
  );
};

export default BlogPage;

