import React from 'react';

const ContatoPage = () => {
  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', textAlign: 'center' }}>Entre em Contato Conosco</h1>
      <p style={{ fontSize: '1.1rem', marginBottom: '2rem', textAlign: 'center' }}>
        Tem dúvidas, sugestões ou precisa de ajuda? Estamos aqui para te atender! Preencha o formulário abaixo e nossa equipe entrará em contato o mais breve possível.
      </p>
      
      <form style={{ backgroundColor: '#f8f9fa', padding: '2rem', borderRadius: '8px' }}>
        <div style={{ marginBottom: '1.5rem' }}>
          <label htmlFor="nome" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>Nome Completo</label>
          <input 
            type="text" 
            id="nome" 
            name="nome" 
            placeholder="Seu nome completo" 
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              borderRadius: '4px', 
              border: '1px solid #ddd',
              fontSize: '1rem'
            }} 
            required 
          />
        </div>
        
        <div style={{ marginBottom: '1.5rem' }}>
          <label htmlFor="email" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>E-mail</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            placeholder="seu.email@exemplo.com" 
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              borderRadius: '4px', 
              border: '1px solid #ddd',
              fontSize: '1rem'
            }} 
            required 
          />
        </div>
        
        <div style={{ marginBottom: '1.5rem' }}>
          <label htmlFor="assunto" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>Assunto</label>
          <select 
            id="assunto" 
            name="assunto" 
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              borderRadius: '4px', 
              border: '1px solid #ddd',
              fontSize: '1rem'
            }} 
            required
          >
            <option value="">Selecione um assunto</option>
            <option value="duvida">Dúvida sobre o curso</option>
            <option value="suporte">Suporte técnico</option>
            <option value="pagamento">Questões de pagamento</option>
            <option value="parceria">Proposta de parceria</option>
            <option value="outro">Outro assunto</option>
          </select>
        </div>
        
        <div style={{ marginBottom: '2rem' }}>
          <label htmlFor="mensagem" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>Mensagem</label>
          <textarea 
            id="mensagem" 
            name="mensagem" 
            placeholder="Digite sua mensagem aqui..." 
            rows="6" 
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              borderRadius: '4px', 
              border: '1px solid #ddd',
              fontSize: '1rem',
              resize: 'vertical'
            }} 
            required
          ></textarea>
        </div>
        
        <button 
          type="submit" 
          style={{ 
            backgroundColor: '#007bff', 
            color: 'white', 
            padding: '1rem 2rem', 
            fontSize: '1.1rem', 
            borderRadius: '4px', 
            border: 'none',
            cursor: 'pointer',
            width: '100%',
            fontWeight: 'bold'
          }}
        >
          Enviar Mensagem
        </button>
      </form>
      
      <div style={{ marginTop: '3rem', textAlign: 'center' }}>
        <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Outras Formas de Contato</h3>
        <p style={{ marginBottom: '0.5rem' }}>
          <strong>E-mail de Suporte:</strong> suporte@iagenerativa.com.br
        </p>
        <p>
          <strong>Redes Sociais:</strong> Nos siga e envie mensagens diretas em nossas redes sociais.
        </p>
        <div style={{ marginTop: '1rem' }}>
          {/* Ícones de redes sociais podem ser adicionados aqui */}
          <a href="#" style={{ margin: '0 0.5rem', color: '#007bff', textDecoration: 'none' }}>Instagram</a>
          <a href="#" style={{ margin: '0 0.5rem', color: '#007bff', textDecoration: 'none' }}>Facebook</a>
          <a href="#" style={{ margin: '0 0.5rem', color: '#007bff', textDecoration: 'none' }}>LinkedIn</a>
        </div>
      </div>
    </div>
  );
};

export default ContatoPage;
