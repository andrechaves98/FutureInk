import React from 'react';

const ProdutoPage = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2.5rem', marginBottom: '2rem' }}>Curso Completo: Criação de Conteúdo com Inteligência Artificial Generativa</h1>
      
      <section style={{ marginBottom: '3rem' }}>
        {/* Vídeo de Vendas/Apresentação (Placeholder) */}
        <div style={{ backgroundColor: '#ccc', height: '400px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '2rem' }}>
          <p>Vídeo de Apresentação do Curso Aqui</p>
        </div>
        <p style={{ fontSize: '1.1rem', lineHeight: '1.6' }}>
          Bem-vindo ao curso que vai revolucionar a forma como você cria conteúdo! Aprenda a dominar as ferramentas de Inteligência Artificial Generativa para produzir textos, imagens e muito mais, de forma mais rápida, eficiente e criativa. Este curso é ideal para criadores de conteúdo, profissionais de marketing, empreendedores e qualquer pessoa que deseje se destacar no mundo digital utilizando o poder da IA.
        </p>
      </section>

      <section>
        <h2 style={{ fontSize: '2rem', marginBottom: '2rem', textAlign: 'center', borderBottom: '2px solid #007bff', paddingBottom: '0.5rem' }}>Mergulhe no Conteúdo de Cada Módulo</h2>
        
        {/* Módulo 1 */}
        <div style={{ marginBottom: '2.5rem', padding: '1.5rem', border: '1px solid #eee', borderRadius: '8px' }}>
          <h3 style={{ fontSize: '1.75rem', color: '#007bff' }}>Módulo 1: Fundamentos da IA Generativa para Criadores</h3>
          <p style={{ marginBottom: '1rem' }}>Construa uma base sólida sobre o que é a IA Generativa, seu impacto na criação de conteúdo, as principais tecnologias envolvidas e as considerações éticas e de marketing para criar conteúdo que se destaca.</p>
          <ul style={{ listStyle: 'disc', marginLeft: '20px' }}>
            <li>O que é Inteligência Artificial Generativa?</li>
            <li>O Impacto da IA Generativa na Criação de Conteúdo.</li>
            <li>Navegando pelas Questões Éticas e o Futuro do Trabalho Criativo.</li>
            <li>Princípios de Marketing para Conteúdo Gerado por IA (A Vaca Roxa na Era da IA).</li>
          </ul>
          <a href="#" style={{ textDecoration: 'none', color: '#007bff', fontWeight: 'bold' }}>Ver detalhes do Módulo 1</a> { /* Link para Hotmart ou página específica */}
        </div>

        {/* Módulo 2 */}
        <div style={{ marginBottom: '2.5rem', padding: '1.5rem', border: '1px solid #eee', borderRadius: '8px' }}>
          <h3 style={{ fontSize: '1.75rem', color: '#007bff' }}>Módulo 2: Dominando Ferramentas de IA para Texto e Imagem (Mão na Massa)</h3>
          <p style={{ marginBottom: '1rem' }}>Aprenda na prática a usar as principais ferramentas de IA para gerar e refinar textos e imagens. Desde a engenharia de prompt até a criação de posts, artigos e visuais impactantes.</p>
          <ul style={{ listStyle: 'disc', marginLeft: '20px' }}>
            <li>A Arte e Ciência do Prompting Eficaz.</li>
            <li>Ferramentas de IA para Geração de Texto (ChatGPT, Gemini, etc.).</li>
            <li>Ferramentas de IA para Geração e Edição de Imagens (Midjourney, DALL-E, Canva AI).</li>
            <li>Revisão, Edição e Humanização de Conteúdo Gerado por IA.</li>
            <li>Exercícios Práticos e Desafios de Prompting.</li>
          </ul>
          <a href="#" style={{ textDecoration: 'none', color: '#007bff', fontWeight: 'bold' }}>Ver detalhes do Módulo 2</a> { /* Link para Hotmart ou página específica */}
        </div>
        
        {/* Adicionar Módulo 3 e 4 conforme o roteiro_geral_produto_ia_generativa.md */}
        <div style={{ marginBottom: '2.5rem', padding: '1.5rem', border: '1px solid #eee', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
          <h3 style={{ fontSize: '1.75rem', color: '#555' }}>Módulo 3: Estratégias e Aplicações Práticas de IA Generativa (Em Breve)</h3>
          <p style={{ marginBottom: '1rem' }}>Explore como integrar a IA em estratégias de conteúdo mais amplas, otimizar fluxos de trabalho, personalizar conteúdo em massa, usar IA para SEO e muito mais.</p>
        </div>

        <div style={{ marginBottom: '2.5rem', padding: '1.5rem', border: '1px solid #eee', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
          <h3 style={{ fontSize: '1.75rem', color: '#555' }}>Módulo 4: Automação, Escala e Monetização com IA (Em Breve)</h3>
          <p style={{ marginBottom: '1rem' }}>Descubra como automatizar tarefas de marketing, escalar sua produção de conteúdo e explorar novas formas de monetização utilizando a Inteligência Artificial.</p>
        </div>

      </section>

      <section style={{ textAlign: 'center', padding: '3rem 1rem', backgroundColor: '#007bff', color: 'white', borderRadius: '8px' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem' }}>Pronto para Revolucionar Seu Conteúdo?</h2>
        <p style={{ fontSize: '1.1rem', marginBottom: '2rem' }}>Junte-se a centenas de criadores que já estão transformando suas ideias em realidade com o poder da IA Generativa.</p>
        <a href="/planos" style={{ textDecoration: 'none', backgroundColor: '#ffc107', color: '#333', padding: '1rem 2.5rem', fontSize: '1.25rem', borderRadius: '5px', fontWeight: 'bold' }}>Quero Me Inscrever Agora!</a>
      </section>

    </div>
  );
};

export default ProdutoPage;
