import React from 'react';

const PoliticaPrivacidadePage = () => {
  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', textAlign: 'center' }}>Política de Privacidade</h1>
      <p style={{ fontSize: '1rem', marginBottom: '1rem', color: '#666' }}>
        Última atualização: 16 de Maio de 2025
      </p>
      
      <div style={{ lineHeight: '1.6' }}>
        <p style={{ marginBottom: '1.5rem' }}>
          A sua privacidade é importante para nós. É política do produto "Criação de Conteúdo com Inteligência Artificial Generativa" respeitar a sua privacidade em relação a qualquer informação sua que possamos coletar em nosso site e outros sites que possuímos e operamos.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>1. Informações que coletamos</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Solicitamos informações pessoais apenas quando realmente precisamos delas para lhe fornecer um serviço. Fazemo-lo por meios justos e legais, com o seu conhecimento e consentimento. Também informamos por que estamos coletando e como será usado.
        </p>
        <p style={{ marginBottom: '1.5rem' }}>
          Apenas retemos as informações coletadas pelo tempo necessário para fornecer o serviço solicitado. Quando armazenamos dados, protegemos dentro de meios comercialmente aceitáveis para evitar perdas e roubos, bem como acesso, divulgação, cópia, uso ou modificação não autorizados.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>2. Uso de informações</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Usamos as informações coletadas para:
        </p>
        <ul style={{ marginBottom: '1.5rem', paddingLeft: '2rem' }}>
          <li>Fornecer, operar e manter nosso site;</li>
          <li>Melhorar, personalizar e expandir nosso site;</li>
          <li>Entender e analisar como você usa nosso site;</li>
          <li>Desenvolver novos produtos, serviços, recursos e funcionalidades;</li>
          <li>Comunicar com você, diretamente ou através de um de nossos parceiros, para fornecer atualizações e outras informações relacionadas ao site e para fins de marketing e promocionais;</li>
          <li>Enviar e-mails;</li>
          <li>Encontrar e prevenir fraudes.</li>
        </ul>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>3. Cookies</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Utilizamos cookies para ajudar a personalizar sua experiência online. Um cookie é um arquivo de texto que é colocado no seu disco rígido por um servidor de páginas web. Os cookies não podem ser usados para executar programas ou enviar vírus para o seu computador. Os cookies são atribuídos a você de forma única e só podem ser lidos pelo servidor web do domínio que emitiu o cookie para você.
        </p>
        <p style={{ marginBottom: '1.5rem' }}>
          Podemos usar cookies para coletar, armazenar e rastrear informações para fins estatísticos e de marketing para operar nosso site. Você tem a capacidade de aceitar ou recusar cookies opcionais. Existem alguns cookies necessários para o funcionamento do nosso site. Esses cookies não exigem seu consentimento.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>4. Serviços de terceiros</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Podemos empregar empresas terceirizadas e indivíduos pelos seguintes motivos:
        </p>
        <ul style={{ marginBottom: '1.5rem', paddingLeft: '2rem' }}>
          <li>Para facilitar nosso site;</li>
          <li>Para fornecer o site em nosso nome;</li>
          <li>Para executar serviços relacionados ao site; ou</li>
          <li>Para nos ajudar a analisar como nosso site é usado.</li>
        </ul>
        <p style={{ marginBottom: '1.5rem' }}>
          Queremos informar aos usuários que esses terceiros têm acesso às suas Informações Pessoais. O motivo é realizar as tarefas atribuídas a eles em nosso nome. No entanto, eles são obrigados a não divulgar ou usar as informações para qualquer outra finalidade.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>5. Segurança</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Valorizamos sua confiança em nos fornecer suas informações pessoais, portanto, estamos nos esforçando para usar meios comercialmente aceitáveis de protegê-las. Mas lembre-se que nenhum método de transmissão pela internet, ou método de armazenamento eletrônico é 100% seguro e confiável, e não podemos garantir sua segurança absoluta.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>6. Links para outros sites</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Nosso site pode conter links para outros sites. Se você clicar em um link de terceiros, será direcionado para esse site. Observe que esses sites externos não são operados por nós. Portanto, recomendamos fortemente que você revise a Política de Privacidade desses sites. Não temos controle e não assumimos responsabilidade pelo conteúdo, políticas de privacidade ou práticas de sites ou serviços de terceiros.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>7. Alterações nesta Política de Privacidade</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Podemos atualizar nossa Política de Privacidade de tempos em tempos. Assim, recomendamos que você revise esta página periodicamente para quaisquer alterações. Notificaremos você sobre quaisquer alterações publicando a nova Política de Privacidade nesta página. Essas alterações são efetivas imediatamente após serem publicadas nesta página.
        </p>
        
        <h2 style={{ fontSize: '1.75rem', marginTop: '2rem', marginBottom: '1rem' }}>8. Contato</h2>
        <p style={{ marginBottom: '1.5rem' }}>
          Se você tiver alguma dúvida ou sugestão sobre nossa Política de Privacidade, não hesite em nos contatar através da página de <a href="/contato" style={{ color: '#007bff', textDecoration: 'none' }}>Contato</a>.
        </p>
      </div>
    </div>
  );
};

export default PoliticaPrivacidadePage;
