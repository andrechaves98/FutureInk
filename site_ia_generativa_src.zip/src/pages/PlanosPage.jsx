import React from 'react';

const PlanosPage = () => {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '3rem' }}>Escolha o Plano Ideal para Você</h1>
      
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'stretch', flexWrap: 'wrap', gap: '2rem' }}>
        
        {/* Plano Exemplo 1 */}
        <div style={{ border: '1px solid #007bff', borderRadius: '8px', padding: '2rem', width: '300px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <h2 style={{ fontSize: '1.75rem', color: '#007bff', marginBottom: '1rem' }}>Plano Completo</h2>
            <p style={{ fontSize: '2.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>R$ 297</p>
            <p style={{ marginBottom: '1.5rem', color: '#555' }}>Acesso vitalício a todos os módulos e atualizações.</p>
            <ul style={{ listStyle: 'none', padding: 0, textAlign: 'left', marginBottom: '2rem' }}>
              <li style={{ marginBottom: '0.5rem' }}>✅ Acesso a todos os Módulos (1, 2, 3 e 4)</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ PDFs completos e detalhados</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Vídeos tutoriais práticos</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Textos de apoio e checklists</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Acesso à comunidade exclusiva</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Certificado de Conclusão</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Suporte prioritário</li>
            </ul>
          </div>
          <a href="#" style={{ textDecoration: 'none', backgroundColor: '#007bff', color: 'white', padding: '1rem 1.5rem', fontSize: '1.1rem', borderRadius: '5px', display: 'block' }}>Assinar Plano Completo</a> {/* Link para checkout Hotmart */}
        </div>

        {/* Plano Exemplo 2 (se houver) - Poderia ser um plano modular ou de assinatura mensal */}
        {/*
        <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '2rem', width: '300px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <h2 style={{ fontSize: '1.75rem', color: '#28a745', marginBottom: '1rem' }}>Plano Mensal</h2>
            <p style={{ fontSize: '2.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>R$ 47/mês</p>
            <p style={{ marginBottom: '1.5rem', color: '#555' }}>Acesso contínuo enquanto a assinatura estiver ativa.</p>
            <ul style={{ listStyle: 'none', padding: 0, textAlign: 'left', marginBottom: '2rem' }}>
              <li style={{ marginBottom: '0.5rem' }}>✅ Acesso a todos os Módulos</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Materiais completos</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Acesso à comunidade</li>
              <li style={{ marginBottom: '0.5rem' }}>✅ Novas aulas e atualizações</li>
            </ul>
          </div>
          <a href="#" style={{ textDecoration: 'none', backgroundColor: '#28a745', color: 'white', padding: '1rem 1.5rem', fontSize: '1.1rem', borderRadius: '5px', display: 'block' }}>Assinar Plano Mensal</a>
        </div>
        */}
      </div>

      <section style={{ marginTop: '4rem', padding: '2rem', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
        <h3 style={{ fontSize: '1.75rem', marginBottom: '1.5rem' }}>O Que Está Incluso em Todos os Planos?</h3>
        <ul style={{ listStyle: 'none', padding: 0, display: 'flex', justifyContent: 'center', gap: '1.5rem', flexWrap: 'wrap' }}>
          <li>✓ Conteúdo 100% Online</li>
          <li>✓ Acesso em Qualquer Dispositivo</li>
          <li>✓ Pagamento Seguro (Via Hotmart)</li>
          <li>✓ Garantia de 7 Dias (Exemplo)</li>
        </ul>
      </section>

      <section style={{ marginTop: '3rem' }}>
        <h3 style={{ fontSize: '1.75rem', marginBottom: '1.5rem' }}>Perguntas Frequentes (FAQ)</h3>
        <div style={{ textAlign: 'left', maxWidth: '700px', margin: '0 auto' }}>
          <div style={{ marginBottom: '1rem' }}>
            <strong>Como funciona o acesso ao curso?</strong>
            <p>Após a confirmação do pagamento, você receberá um e-mail com os dados de acesso à nossa área de membros exclusiva na Hotmart.</p>
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <strong>Quais são as formas de pagamento?</strong>
            <p>Aceitamos cartão de crédito (em até X vezes), PIX e boleto bancário através da plataforma Hotmart.</p>
          </div>
          {/* Adicionar mais FAQs */}
        </div>
      </section>

    </div>
  );
};

export default PlanosPage;

