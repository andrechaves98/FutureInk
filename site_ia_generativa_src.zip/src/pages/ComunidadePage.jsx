import React from 'react';

const ComunidadePage = () => {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem' }}>Nossa Comunidade</h1>
      <p style={{ fontSize: '1.2rem', marginBottom: '1.5rem', maxWidth: '700px', margin: '0 auto 1.5rem auto' }}>
        Junte-se à nossa comunidade exclusiva de criadores de conteúdo e entusiastas da Inteligência Artificial Generativa! 
        Este é o seu espaço para trocar ideias, tirar dúvidas, compartilhar seus projetos, fazer networking e aprender 
        ainda mais sobre o universo da IA.
      </p>
      
      <div style={{ margin: '2rem 0' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Como Participar?</h2>
        <p style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Nossa principal plataforma de comunidade é o Discord.</p>
        <a 
          href="#"  // Substituir pelo link real do Discord
          target="_blank" 
          rel="noopener noreferrer" 
          style={{
            display: 'inline-block',
            padding: '1rem 2rem',
            fontSize: '1.25rem',
            color: 'white',
            backgroundColor: '#5865F2', // Cor do Discord
            textDecoration: 'none',
            borderRadius: '8px',
            fontWeight: 'bold'
          }}
        >
          Entrar no Discord
        </a>
      </div>

      <div style={{ marginTop: '3rem', padding: '2rem', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
        <h3 style={{ fontSize: '1.75rem', marginBottom: '1.5rem' }}>O Que Esperar da Comunidade?</h3>
        <ul style={{ listStyle: 'none', padding: 0, maxWidth: '600px', margin: '0 auto', textAlign: 'left' }}>
          <li style={{ marginBottom: '1rem', paddingLeft: '1.5rem', position: 'relative' }}>
            <span style={{ position: 'absolute', left: '0', color: '#007bff' }}>✓</span> 
            Discussões e aprendizado sobre IA Generativa.
          </li>
          <li style={{ marginBottom: '1rem', paddingLeft: '1.5rem', position: 'relative' }}>
            <span style={{ position: 'absolute', left: '0', color: '#007bff' }}>✓</span> 
            Suporte e ajuda mútua entre os membros.
          </li>
          <li style={{ marginBottom: '1rem', paddingLeft: '1.5rem', position: 'relative' }}>
            <span style={{ position: 'absolute', left: '0', color: '#007bff' }}>✓</span> 
            Compartilhamento de prompts, ferramentas e descobertas.
          </li>
          <li style={{ marginBottom: '1rem', paddingLeft: '1.5rem', position: 'relative' }}>
            <span style={{ position: 'absolute', left: '0', color: '#007bff' }}>✓</span> 
            Sessões de Q&A e eventos exclusivos (planejados para o futuro).
          </li>
          <li style={{ paddingLeft: '1.5rem', position: 'relative' }}>
            <span style={{ position: 'absolute', left: '0', color: '#007bff' }}>✓</span> 
            Networking com outros profissionais da área.
          </li>
        </ul>
      </div>

      <p style={{ marginTop: '3rem', fontSize: '1.1rem' }}>
        Acreditamos no poder da colaboração para impulsionar o conhecimento. Esperamos você lá!
      </p>
    </div>
  );
};

export default ComunidadePage;

