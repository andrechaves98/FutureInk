import React from 'react';

// Importando todos os componentes de página
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ProdutoPage from './pages/ProdutoPage';
import PlanosPage from './pages/PlanosPage';
import BlogPage from './pages/BlogPage';
import BlogPostPage from './pages/BlogPostPage';
import ComunidadePage from './pages/ComunidadePage';
import ContatoPage from './pages/ContatoPage';
import TermosUsoPage from './pages/TermosUsoPage';
import PoliticaPrivacidadePage from './pages/PoliticaPrivacidadePage';

const App = () => {
  // Implementação básica de roteamento
  // Em uma aplicação real, usaríamos React Router
  const getPage = () => {
    const path = window.location.pathname;
    
    switch(path) {
      case '/':
        return <HomePage />;
      case '/produto':
        return <ProdutoPage />;
      case '/planos':
        return <PlanosPage />;
      case '/blog':
        return <BlogPage />;
      case '/comunidade':
        return <ComunidadePage />;
      case '/contato':
        return <ContatoPage />;
      case '/termos-de-uso':
        return <TermosUsoPage />;
      case '/politica-de-privacidade':
        return <PoliticaPrivacidadePage />;
      default:
        // Verificar se é uma página de post de blog
        if (path.startsWith('/blog/')) {
          return <BlogPostPage />;
        }
        // Página não encontrada, redirecionar para home
        return <HomePage />;
    }
  };

  return (
    <div className="app" style={{ 
      display: 'flex', 
      flexDirection: 'column',
      minHeight: '100vh'
    }}>
      <Navbar />
      <main style={{ flex: 1 }}>
        {getPage()}
      </main>
      <Footer />
    </div>
  );
};

export default App;
