import React from 'react';

const Footer = () => {
  return (
    <footer style={{ backgroundColor: '#333', color: '#fff', padding: '2rem', textAlign: 'center', marginTop: '2rem' }}>
      <div>
        <p>&copy; {new Date().getFullYear()} Produto IA Generativa. Todos os direitos reservados.</p>
      </div>
      <div style={{ marginTop: '1rem' }}>
        <a href="/termos-de-uso" style={{ color: '#fff', textDecoration: 'none', marginRight: '1rem' }}>Termos de Uso</a>
        <a href="/politica-de-privacidade" style={{ color: '#fff', textDecoration: 'none' }}>Política de Privacidade</a>
      </div>
      {/* Ícones de redes sociais podem ser adicionados aqui */}
    </footer>
  );
};

export default Footer;
