import React from 'react';

const Navbar = () => {
  return (
    <nav style={{ backgroundColor: '#f0f0f0', padding: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div>
        <a href="/" style={{ textDecoration: 'none', color: '#333', fontWeight: 'bold' }}>Logo</a>
      </div>
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex' }}>
        <li style={{ marginLeft: '1rem' }}><a href="/produto" style={{ textDecoration: 'none', color: '#333' }}>Sobre o Produto</a></li>
        <li style={{ marginLeft: '1rem' }}><a href="/planos" style={{ textDecoration: 'none', color: '#333' }}>Planos</a></li>
        <li style={{ marginLeft: '1rem' }}><a href="/blog" style={{ textDecoration: 'none', color: '#333' }}>Blog</a></li>
        <li style={{ marginLeft: '1rem' }}><a href="/comunidade" style={{ textDecoration: 'none', color: '#333' }}>Comunidade</a></li>
        <li style={{ marginLeft: '1rem' }}><a href="/contato" style={{ textDecoration: 'none', color: '#333' }}>Contato</a></li>
        <li style={{ marginLeft: '1rem' }}><a href="#" style={{ textDecoration: 'none', color: '#333' }}>Login/Área de Membros</a></li> {/* Link para Hotmart será aqui */}      
      </ul>
    </nav>
  );
};

export default Navbar;
